package desarrollosoftwareisabados.springbootthymeleafcrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootThymeleafCrudApplicationTests {

    @Test
    void contextLoads() {
    }

}
